import email
from email.message import EmailMessage
from email.policy import EmailPolicy
from aiogram import Bot, Dispatcher, executor, types
import logging
from aiogram.dispatcher.filters import Text
from aiogram.dispatcher import FSMContext
from aiogram.dispatcher.filters.state import State, StatesGroup
from aiogram.utils.markdown import hide_link
from sqlalchemy import create_engine, Column, Integer, String
from sqlalchemy.orm import declarative_base, sessionmaker
from config import *
from states import *
import smtplib
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText

import os

API_TOKEN = '6115890388:AAGdbk7ff3Aut2Y83qZ3-g-kk4IcPlUBPQQ'

logging.basicConfig(level=logging.INFO)

bot = Bot(token=API_TOKEN)
dp = Dispatcher(bot)

logo = open('photo_2023-03-30_10-11-54.jpg', 'rb')
photo1 = open('шмотки\жопа.jpg', 'rb')
photo2 = open('шмотки\86.jpg', 'rb')
photo3 = open('шмотки\стизус.jpg', 'rb')
photo4 = open('шмотки\capybara.jpg', 'rb')
photo5 = open('шмотки\Джет.jpg', 'rb')
photo6 = open('шмотки\фэмили.jpg', 'rb')
photo7 = open('шмотки\токсик.jpg', 'rb')
photo8 = open('шмотки\рейна.jpg', 'rb')
photo9 = open('шмотки\стизус-худи.jpg', 'rb')
photo10 = open('шмотки\капи-худи.jpg', 'rb')
photo11 = open('шмотки\стизус-шоппер.jpg', 'rb')
photo12 = open('шмотки\капи-шоппер.jpg', 'rb')
photo13 = open('шмотки\photo_2023-04-24_19-27-18.jpg', 'rb')
@dp.message_handler(commands='start') 
async def send_welcome(message: types.Message):
   keyboard = types.ReplyKeyboardMarkup(resize_keyboard=True)
   buttons = ["Все команды"]
   keyboard.add(*buttons)
   await message.answer("Вас приветствует IHNDesigner Бот.\nЗдесь вы сможете посмотреть наш каталог, а так же заказать одежду!\nЧтобы посмотреть доступные комманды напиши /help или нажмите на кнопку ниже!", reply_markup=keyboard)
   await bot.send_photo(chat_id=message.chat.id, photo=logo)

@dp.message_handler(Text(equals="Все команды"))
async def send_help(message: types.Message):
   keyboard = types.ReplyKeyboardMarkup(resize_keyboard=True)
   buttons = ["Каталог", "Заказать", "Контакты"]
   keyboard.add(*buttons)
   await message.answer("Доступные команды:\n/contacts - Наши контакты\n/order - Сделать заказ\n/catalog - Каталог", reply_markup=keyboard)

@dp.message_handler(Text(equals="Вернуться назад"))
async def send_help(message: types.Message):
   keyboard = types.ReplyKeyboardMarkup(resize_keyboard=True)
   buttons = ["Каталог", "Заказать", "Контакты"]
   keyboard.add(*buttons)
   await message.answer("Доступные команды:\n/contacts - Наши контакты\n/order - Сделать заказ\n/catalog - Каталог", reply_markup=keyboard)

@dp.message_handler(commands=['help']) 
async def send_help(message: types.Message):
   keyboard = types.ReplyKeyboardMarkup(resize_keyboard=True)
   buttons = ["Каталог", "Заказать", "Контакты"]
   keyboard.add(*buttons)
   await message.answer("Доступные команды:\n/contacts - Наши контакты\n/catalog - Каталог", reply_markup=keyboard)

@dp.message_handler(commands=['contacts']) 
async def send_contacts(message: types.Message):
   await message.answer("Сообщество ВК: https://vk.com/ihndesigns\nКонтактные телефоны: +7(928)320-69-57\nМой Телеграм: @IHNDESIGNER\nТелеграм канал: https://t.me/IHNDESINGS\nEmail: raich.nikolai@yandex.ru")

@dp.message_handler(Text(equals="Контакты"))
async def send_contacts(message: types.Message):
   await message.answer("Сообщество ВК: https://vk.com/ihndesigns\nКонтактные телефоны: +7(928)320-69-57\nМой Телеграм: @IHNDESIGNER\nТелеграм канал: https://t.me/IHNDESINGS\nEmail: raich.nikolai@yandex.ru")

@dp.message_handler(Text(equals="Каталог"))
async def catalog_show(message: types.Message):
    keyboard = types.ReplyKeyboardMarkup(resize_keyboard=True)
    buttons = ["Майки", "Худи", "Шопперы", "Вернуться назад"]
    keyboard.add(*buttons)
    await message.answer("Наш каталог:\nМайки (8)\nХуди (2)\nШопперы (2)", reply_markup=keyboard)

@dp.message_handler(Text(equals="Заказать"))
async def send_cltgtshrt(message: types.Message):
   keyboard = types.ReplyKeyboardMarkup(resize_keyboard=True)
   buttons = ["майки", "худи", "шопперы", "Отменить заказ"]
   keyboard.add(*buttons)
   await message.answer("Выберете что хотите заказать:\nМайки\nХуди\nШопперы", reply_markup=keyboard)

@dp.message_handler(Text(equals="майки"))
async def order_shirt(message: types.Message):
   await message.answer("Каталог одежды:\n№1. Майка ЖОПА\n№2. Майка AE86\n№3. Майка Стизус\n№4. Майка Капибара\n№5. Майка Джет\n№6. Майка Family Affair\n№7. Майка Токсик\n№8. Майка Рейна\n№9. Майка 12.5.1\n№10. Худи Стизус\n№11. Худи Капибара\n№12. Шоппер Стизус\n№13. Шоппер Капибара")
   await message.answer("Введите ваше имя:")
   await email()
#---------Состояние 1------------------------
@dp.message_handler(state=email)
async def state1(message: types.message, state: FSMContext):
    answer = message.text
    await state.update_data(Test1=answer)
    await message.answer('Введите свои контактные данные для обратной связи (Email или Номер телефoна)')
    await email()
#---------Состояние 2------------------------
@dp.message_handler(state=email)
async def state2(message: types.message, state: FSMContext):
    answer = message.text
    await state.update_data(Test2=answer)
    await message.answer('Введите номер одежды из указанных и размер(например: 13/№13 XL)')
    await email()
#---------Состояние 3------------------------
@dp.message_handler(state=email)
async def state3(message: types.message, state: FSMContext):
    answer = message.text
    await state.update_data(Test3=answer)
#-----Берёт значения из data---------
    data = await state.get_data()
    name = data.get('Test1')
    contact = data.get('Test2')
    msg = data.get('Test3')
    await message.answer(f'{message.from_user.full_name}, ваш заказ:\n'
                        f'Ваше ФИО: <b>{name}</b>\n'
                        f'Ваша почта/номер телефона: <b>{contact}</b>\n'
                        f'Номер одежды и размер: <b>{msg}</b>')
#------Та самая функция, которая отправляет результаты на Email address-------
    addr_from = email
    addr_to = 'ihatenixordesings@gmail.com'
    mgs = MIMEMultipart()
    mgs['From'] = addr_from
    mgs['To'] = addr_to
    mgs['Subject'] = 'Новая заявка!'
    body = (f'''
    Ваше имя {name}
    Контакты для обратной связи {contact}
    номер одежды: {msg}
    ''')
    mgs.attach(MIMEText(body, 'plain'))
    smtpObj = smtplib.SMTP('ihatenixordesings@gmail.com', 587)
    smtpObj.starttls()
    smtpObj.send_message(mgs)
    smtpObj.quit()
#---------Выход из машины состояний-----------
    await state.finish()

@dp.message_handler(Text(equals="Отменить заказ"))
async def catalog_show(message: types.Message):
   keyboard = types.ReplyKeyboardMarkup(resize_keyboard=True)
   buttons = ["Каталог", "Заказать", "Контакты"]
   keyboard.add(*buttons)
   await message.answer("Доступные команды:\n/contacts - Наши контакты\n/catalog - Каталог", reply_markup=keyboard)

@dp.message_handler(Text(equals="Назад"))
async def catalog_show(message: types.Message):
    keyboard = types.ReplyKeyboardMarkup(resize_keyboard=True)
    buttons = ["Майки", "Худи", "Шопперы", "Вернуться назад"]
    keyboard.add(*buttons)
    await message.answer("Наш каталог:\nМайки (8)\nХуди (2)\nШопперы (2)", reply_markup=keyboard)

@dp.message_handler(Text(equals="Майки")) 
async def send_tshirts(message: types.Message):
   keyboard = types.ReplyKeyboardMarkup(resize_keyboard=True)
   buttons = ["ЖОПА", "АЕ86", "Стизус", "Капибара", "Джет", "Family Affair", "Токсик", "Рейна", "12.5.1", "Назад"]
   keyboard.add(*buttons)
   await message.answer("Каталог маек:\n№1. Майка ЖОПА\n№2. Майка AE86\n№3. Майка Стизус\n№4. Майка Капибара\n№5. Майка Джет\n№6. Майка Family Affair\n№7. Майка Токсик\n№8. Майка Рейна\n№9. Майка 12.5.1", reply_markup=keyboard)

@dp.message_handler(Text(equals="Все майки")) 
async def send_tshirts(message: types.Message):
   keyboard = types.ReplyKeyboardMarkup(resize_keyboard=True)
   buttons = ["ЖОПА", "АЕ86", "Стизус", "Капибара", "Джет", "Family Affair", "Токсик", "Рейна", "12.5.1", "Назад"]
   keyboard.add(*buttons)
   await message.answer("Каталог маек:\n№1. Майка ЖОПА\n№2. Майка AE86\n№3. Майка Стизус\n№4. Майка Капибара\n№5. Майка Джет\n№6. Майка Family Affair\n№7. Майка Токсик\n№8. Майка Рейна\n№9. Майка 12.5.1", reply_markup=keyboard)

@dp.message_handler(Text(equals="Худи")) 
async def send_tshirts(message: types.Message):
   keyboard = types.ReplyKeyboardMarkup(resize_keyboard=True)
   buttons = ["Стизус Худи", "Капибара Худи", "Назад"]
   keyboard.add(*buttons)
   await message.answer("Каталог худи:\n№1. Худи Стизус\n№2. Худи Капибара", reply_markup=keyboard)

@dp.message_handler(Text(equals="Все худи")) 
async def send_tshirts(message: types.Message):
   keyboard = types.ReplyKeyboardMarkup(resize_keyboard=True)
   buttons = ["Стизус Худи", "Капибара Худи", "Назад"]
   keyboard.add(*buttons)
   await message.answer("Каталог худи:\n№1. Худи Стизус\n№2. Худи Капибара", reply_markup=keyboard)

@dp.message_handler(Text(equals="Шопперы")) 
async def send_tshirts(message: types.Message):  
   keyboard = types.ReplyKeyboardMarkup(resize_keyboard=True)
   buttons = ["Стизус Шоппер", "Капибара Шоппер", "Назад"]
   keyboard.add(*buttons)
   await message.answer("Каталог шопперов:\n№1. Шоппер Стизус\n№2. Шоппер Капибара", reply_markup=keyboard)

@dp.message_handler(Text(equals="Все шопперы")) 
async def send_tshirts(message: types.Message):  
   keyboard = types.ReplyKeyboardMarkup(resize_keyboard=True)
   buttons = ["Стизус Шоппер", "Капибара Шоппер", "Назад"]
   keyboard.add(*buttons)
   await message.answer("Каталог шопперов:\n№1. Шоппер Стизус\n№2. Шоппер Капибара", reply_markup=keyboard)

@dp.message_handler(Text(equals="ЖОПА"))
async def send_cltgtshrt(message: types.Message):
   keyboard = types.ReplyKeyboardMarkup(resize_keyboard=True)
   buttons = ["Заказать", "Все майки"]
   keyboard.add(*buttons)
   await message.answer("Майка ЖОПА\nЦена: 1500\nРазмеры: S, M, L, XL, XXL", reply_markup=keyboard)
   await bot.send_photo(chat_id=message.chat.id, photo=photo1)

@dp.message_handler(Text(equals="АЕ86"))
async def send_cltgtshrt(message: types.Message):
   keyboard = types.ReplyKeyboardMarkup(resize_keyboard=True)
   buttons = ["Заказать", "Все майки"]
   keyboard.add(*buttons)
   await message.answer("Майка АЕ86\nЦена: 1700\nРазмеры: S, M, L, XL, XXL", reply_markup=keyboard)
   await bot.send_photo(chat_id=message.chat.id, photo=photo2)

@dp.message_handler(Text(equals="Стизус"))
async def send_cltgtshrt(message: types.Message):
   keyboard = types.ReplyKeyboardMarkup(resize_keyboard=True)
   buttons = ["Заказать", "Все майки"]
   keyboard.add(*buttons)
   await message.answer("Майка Стизус\nЦена: 1600\nРазмеры: S, M, L, XL, XXL", reply_markup=keyboard)
   await bot.send_photo(chat_id=message.chat.id, photo=photo3)

@dp.message_handler(Text(equals="Капибара"))
async def send_cltgtshrt(message: types.Message):
   keyboard = types.ReplyKeyboardMarkup(resize_keyboard=True)
   buttons = ["Заказать", "Все майки"]
   keyboard.add(*buttons)
   await message.answer("Майка Капибара\nЦена: 1600\nРазмеры: S, M, L, XL, XXL", reply_markup=keyboard)
   await bot.send_photo(chat_id=message.chat.id, photo=photo4)

@dp.message_handler(Text(equals="Джет"))
async def send_cltgtshrt(message: types.Message):
   keyboard = types.ReplyKeyboardMarkup(resize_keyboard=True)
   buttons = ["Заказать", "Все майки"]
   keyboard.add(*buttons)
   await message.answer("Майка Джет\nЦена: 1400\nРазмеры: S, M, L, XL, XXL", reply_markup=keyboard)
   await bot.send_photo(chat_id=message.chat.id, photo=photo5)

@dp.message_handler(Text(equals="Family Affair"))
async def send_cltgtshrt(message: types.Message):
   keyboard = types.ReplyKeyboardMarkup(resize_keyboard=True)
   buttons = ["Заказать", "Все майки"]
   keyboard.add(*buttons)
   await message.answer("Майка Family Affair\nЦена: 1600\nРазмеры: S, M, L, XL, XXL", reply_markup=keyboard)
   await bot.send_photo(chat_id=message.chat.id, photo=photo6)

@dp.message_handler(Text(equals="Токсик"))
async def send_cltgtshrt(message: types.Message):
   keyboard = types.ReplyKeyboardMarkup(resize_keyboard=True)
   buttons = ["Заказать", "Все майки"]
   keyboard.add(*buttons)
   await message.answer("Майка Токсик\nЦена: 1500\nРазмеры: S, M, L, XL, XXL", reply_markup=keyboard)
   await bot.send_photo(chat_id=message.chat.id, photo=photo7)

@dp.message_handler(Text(equals="Рейна"))
async def send_cltgtshrt(message: types.Message):
   keyboard = types.ReplyKeyboardMarkup(resize_keyboard=True)
   buttons = ["Заказать", "Все майки"]
   keyboard.add(*buttons)
   await message.answer("Майка Рейна\nЦена: 1400\nРазмеры: S, M, L, XL, XXL", reply_markup=keyboard)
   await bot.send_photo(chat_id=message.ch5at.id, photo=photo8)

@dp.message_handler(Text(equals="12.5.1"))
async def send_cltgtshrt(message: types.Message):
   keyboard = types.ReplyKeyboardMarkup(resize_keyboard=True)
   buttons = ["Заказать", "Все майки"]
   keyboard.add(*buttons)
   await message.answer("Майка 12.5.1\nЦена: 1400\nРазмеры: S, M, L, XL, XXL", reply_markup=keyboard)
   await bot.send_photo(chat_id=message.chat.id, photo=photo13)

@dp.message_handler(Text(equals="Стизус Худи"))
async def send_cltgtshrt(message: types.Message):
   keyboard = types.ReplyKeyboardMarkup(resize_keyboard=True)
   buttons = ["Заказать", "Все худи"]
   keyboard.add(*buttons)
   await message.answer("Худи Стизус\nЦена: 2200\nРазмеры: S, M, L, XL, XXL", reply_markup=keyboard)
   await bot.send_photo(chat_id=message.chat.id, photo=photo9)

@dp.message_handler(Text(equals="Капибара Худи"))
async def send_cltgtshrt(message: types.Message):
   keyboard = types.ReplyKeyboardMarkup(resize_keyboard=True)
   buttons = ["Заказать", "Все худи"]
   keyboard.add(*buttons)
   await message.answer("Худи Капибара\nЦена: 2200\nРазмеры: S, M, L, XL, XXL", reply_markup=keyboard)
   await bot.send_photo(chat_id=message.chat.id, photo=photo10)

@dp.message_handler(Text(equals="Стизус Шоппер"))
async def send_cltgtshrt(message: types.Message):
   keyboard = types.ReplyKeyboardMarkup(resize_keyboard=True)
   buttons = ["Заказать", "Все шопперы"]
   keyboard.add(*buttons)
   await message.answer("Шоппер Стизус\nЦена: 1200", reply_markup=keyboard)
   await bot.send_photo(chat_id=message.chat.id, photo=photo11)

@dp.message_handler(Text(equals="Капибара Шоппер"))
async def send_cltgtshrt(message: types.Message):
   keyboard = types.ReplyKeyboardMarkup(resize_keyboard=True)
   buttons = ["Заказать", "Все шопперы"]
   keyboard.add(*buttons)
   await message.answer("Шоппер Капибара\nЦена: 1200", reply_markup=keyboard)
   await bot.send_photo(chat_id=message.chat.id, photo=photo12)

@dp.message_handler()
async def unknown(message: types.Message):
   keyboard = types.ReplyKeyboardMarkup(resize_keyboard=True)
   buttons = ["Все команды"]
   keyboard.add(*buttons)
   await message.answer('Простите, но я не понимаю вас! Чтобы узнать список доступных комманд, напишите /help. или посмотрите список команд!', reply_markup=keyboard)
 
if __name__ == '__main__':
   executor.start_polling(dp, skip_updates=True)