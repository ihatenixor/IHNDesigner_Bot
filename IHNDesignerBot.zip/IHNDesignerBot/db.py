#----Импорт библиотек--------
import logging
from aiogram import Bot, types, Dispatcher, executor
from aiogram.dispatcher.filters.state import StatesGroup, State
from aiogram.dispatcher import FSMContext
from config import token, email, password
from states import Email
from aiogram.contrib.fsm_storage.memory import MemoryStorage
import smtplib 
import os
from email.mime.multipart import MIMEMultipart                 
from email.mime.text import MIMEText               
storage = MemoryStorage()
bot = Bot(token=token, parse_mode=types.ParseMode.HTML)
dp = Dispatcher(bot, storage=storage)

logging.basicConfig(level=logging.INFO)

@dp.message_handler(commands=('start'))
async def start_command(message: types.Message):
    await message.reply("Привет, я бот Гоша!\nЧто бы отправить от меня Email, напиши /email")

@dp.message_handler(commands=(''))
async def email(message: types.message):
    await message.answer('Привет! Ты начал(а) заполнять форму на заявку! \nВведите своё полное ФИО: ')
    await Email.Test1.set()

@dp.message_handler(state=Email.Test1)
async def state1(message: types.message, state: FSMContext):
    answer = message.text
    await state.update_data(Test1=answer)
    await message.answer('Введите свои контактные данные для обратной связи (Email или Номер телефoна)')
    await Email.Test2.set()

@dp.message_handler(state=Email.Test2)
async def state2(message: types.message, state: FSMContext):
    answer = message.text
    await state.update_data(Test2=answer)
    await message.answer('Введите Сообщение, которое хотите отправить')
    await Email.Test3.set()

@dp.message_handler(state=Email.Test3)
async def state3(message: types.message, state: FSMContext):
    answer = message.text
    await state.update_data(Test3=answer)
#-----Берёт значения из data---------
    data = await state.get_data()
    name = data.get('Test1')
    contact = data.get('Test2')
    msg = data.get('Test3')
    await message.answer(f'{message.from_user.full_name}, вот письмо составленное вами:\n'
                        f'Ваше ФИО: <b>{name}</b>\n'
                        f'Ваша почта/номер телефона: <b>{contact}</b>\n'
                        f'Ваше сообщение: <b>{msg}</b>')
#------Та самая функция, которая отправляет результаты на Email address-------
    addr_from = email
    addr_to = 'EMAIL@mail.ru'
    mgs = MIMEMultipart()
    mgs['From'] = addr_from
    mgs['To'] = addr_to
    mgs['Subject'] = 'Новая заявка!'
    body = (f'''
    Автор заявки {name}
    Контакты для обратной связи {contact}
    Текст заявки: {msg}
    ''')
    mgs.attach(MIMEText(body, 'plain'))
    smtpObj = smtplib.SMTP('smtp.mail.ru', 587)
    smtpObj.starttls()
    smtpObj.login(addr_from, password)
    smtpObj.send_message(mgs)
    smtpObj.quit()
    await state.finish()